// Function to clear all form fields
function clearFormFields() {
    document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"]').forEach(input => {
        input.value = '';
    });
}

// Function to handle sign-up form submission
function handleSignUp(event) {
    event.preventDefault();
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const confirmPassword = document.getElementById('signup-confirm-password').value;
    const username = document.getElementById('signup-username').value;

    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
    }

    // Save user data (in this example, just use localStorage)
    localStorage.setItem('user', JSON.stringify({ email, password, username }));
    alert("Registration successful!");

    // Switch to login form
    showLoginForm();
    clearFormFields(); // Clear form fields when switching to login form
}

// Function to handle login form submission
function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    const user = JSON.parse(localStorage.getItem('user'));

    if (user && user.email === email && user.password === password) {
        alert("Login successful!");
    } else {
        alert("Invalid email or password.");
    }
}

// Function to show the sign-up form
function showSignUpForm() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('signup-form').style.display = 'block';
    clearFormFields(); // Clear form fields when showing the sign-up form
}

// Function to show the login form
function showLoginForm() {
    document.getElementById('signup-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
    clearFormFields(); // Clear form fields when showing the login form
}

// Function to toggle password visibility
function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    if (field.type === "password") {
        field.type = "text";
    } else {
        field.type = "password";
    }
}

// Clear form fields when the page loads
document.addEventListener('DOMContentLoaded', clearFormFields);